CREATE DATABASE  IF NOT EXISTS `Profiles` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `Profiles`;
SET NAMES utf8 ;

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Users` (
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(250) NOT NULL,
  `profilePicture` varchar(250) NOT NULL,
  `marks` decimal(10,0) NOT NULL,
  `status` int(11) NOT NULL,
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


/*
-- Query: SELECT * FROM Users.Profiles
LIMIT 0, 1000

-- Date: 2019-06-05 00:13
*/
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Black','Widow','bwidow@gmail.com',89,1,'uploads/Black.jpg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Captain','America','captain@icloud.com',199,1,'uploads/Captain.jpg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Cool','Joe','cool@gmail.com',90,1,'uploads/Cool.jpeg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Edna ','Mode','edna@yahoo.com',60,0,'uploads/Edna .jpeg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Hulk','Banner','hulk@yahoo.com',199,1,'uploads/Hulk.jpg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Mr Incredible','Parr','incredible@icloud.com',100,1,'uploads/Mr Incredible.jpeg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Iron','Man','ironman@icloud.com',200,1,'uploads/Iron.png');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Ishita ','Thakkar','ishi@gmail.com',100,1,'uploads/Ishita .jpeg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Jack','Jack','jackjack@icloud.com',99,0,'uploads/Jack.jpeg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Jessi','Toy','jessie@gmail.com',65,0,'uploads/Jessi.jpeg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Soniya','Rode','sr@gmail.com',100,1,'uploads/Soniya.jpeg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Thor','Odin','thor@icloud.com',200,1,'uploads/Thor.jpg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Wonder','Women','wonder@gmail.com',100,1,'uploads/Wonder.jpg');
INSERT INTO `` (`firstName`,`lastName`,`email`,`marks`,`status`,`profilePicture`) VALUES ('Woody','Toy','woody@gmail.com',67,0,'uploads/Woody.jpeg');
