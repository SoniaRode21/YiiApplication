<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Profiles".
 *
 * @property string $firstName
 * @property string $lastName
 * @property string $email
 * @property int $marks
 * @property int $status
 */
class Profiles extends \yii\db\ActiveRecord
{   public $file;
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Profiles';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['firstName', 'lastName', 'email', 'marks', 'status'], 'required'],
            ['file', 'required', 'when' => function ($model) {
        return $model->profilePicture != '';
    }],
            [['marks', 'status'], 'integer'],
            [['firstName', 'lastName'], 'string', 'max' => 25],
            [['email'], 'string', 'max' => 45],
            [['file'],'file'],
            [['profilePicture'],'string','max'=>250],
            [['email'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'firstName' => 'First Name',
            'lastName' => 'Last Name',
            'email' => 'Email',
            'marks' => 'Marks',
            'status' => 'Status',
            'file'=>'Profile Picture'
        ];
    }
}
