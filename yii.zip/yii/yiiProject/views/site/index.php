<?php

use yii\helpers\Html;

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>

<div class="site-index">

    <div class="jumbotron">
       
        <p class="lead">Displaying records having active status = 1</p>

        
    </div>

    <div class="body-content">

         <?php 
   //Query to get users with active status  
    $customer = app\models\Profiles::find()
    ->where(['status' =>1])
    ->all();
    
    
    ?>
    <table class="table table-bordered">
         <tr> 
            <th>Name </th>
            <th>Email</th>
            <th>Marks</th>
            <th>Profile Picture</th>
        </tr>

    <?php foreach ($customer as $u): 
         $fname = $u->firstName;
         $lname=$u->lastName;
         $email = $u->email;
         $marks=$u->marks;
         $img=(Yii::getAlias('@web').'/'.$u->profilePicture);
         
?>  
       
        
    <tr >
        <td><?php echo $fname."   ".$lname?></td>
        <td><?php echo $email; ?></td>
        <td><?php echo $marks; ?></td>
        <td><?php echo Html::img($img,['height'=>'200px', 'width'=>'200px']);?>
</td>
       
    </tr>
    <?php endforeach; ?>
</table>

    </div>
</div>
